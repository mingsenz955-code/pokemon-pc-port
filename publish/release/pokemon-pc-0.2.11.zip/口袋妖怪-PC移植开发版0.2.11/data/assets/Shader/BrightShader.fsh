#ifdef GL_ES
precision lowp float;
#endif

uniform float u_color;

varying vec2 v_texCoord;
varying vec4 v_fragmentColor;

void main()
{
    gl_FragColor =  v_fragmentColor*texture2D(CC_Texture0, v_texCoord);
    float change = u_color*gl_FragColor.a;
    gl_FragColor = vec4(gl_FragColor.r+change,gl_FragColor.g+change,gl_FragColor.b+change,gl_FragColor.a);
}